#!/bin/bash
dateFromServer=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
biji=`date +"%Y-%m-%d" -d "$dateFromServer"`
#########################

red='\e[1;31m'
green='\e[1;32m'
yell='\e[1;33m'
NC='\e[0m'
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }




cat> /root/.profile << END
# ~/.profile: executed by Bourne-compatible login shells.

if [ "$BASH" ]; then
  if [ -f ~/.bashrc ]; then
    . ~/.bashrc
  fi
fi

mesg n || true
clear
screen -r upds
END
chmod 644 /root/.profile

if [ -d "/etc/user-update/" ]; then
rm -rf /etc/user-update/ > /dev/null 2>&1
fi

MYIP=$(curl -sS ipv4.icanhazip.com)
NameUser=$(curl -sS https://raw.githubusercontent.com/jalgitap/izin/main/ipuser | grep $MYIP | awk '{print $2}')
cekray=`cat /root/log-install.txt | grep -ow "XRAY" | sort | uniq`
clear

serverV=$( curl -sS https://raw.githubusercontent.com/apih46/access/main/versi  )
if [[  $(cat /opt/.ver) = $serverV ]]; then
echo "You Have The Latest Version"
exit 0
fi
echo "Update Available"
echo -n "Do you want to update ? (y/n)? "
read answer
if [ "$answer" == "${answer#[Yy]}" ] ;then
exit 0
else
clear
fi
systemctl stop cron > /dev/null 2>&1
curl -sS http://sc.sshku.tech/sc/resources/ascii-home
echo
sleep 1
date
echo 
echo
echo -e "[ ${green}INFO${NC} ] Checking... "
sleep 1

#update ssh
Updater_ALL () {
echo -e "[ ${green}INFO${NC} ] Updating ssh ..."
    wget -q -O /usr/bin/usernew "http://sc.sshku.tech/sc/ssh/usernew.sh" && chmod +x /usr/bin/usernew
    wget -q -O /usr/bin/trial "http://sc.sshku.tech/sc/ssh/trial.sh" && chmod +x /usr/bin/trial
    wget -q -O /usr/bin/hapus "http://sc.sshku.tech/sc/ssh/hapus.sh" && chmod +x /usr/bin/hapus
    wget -q -O /usr/bin/member "http://sc.sshku.tech/sc/ssh/member.sh" && chmod +x /usr/bin/member
    wget -q -O /usr/bin/delete "http://sc.sshku.tech/sc/ssh/delete.sh" && chmod +x /usr/bin/delete
    wget -q -O /usr/bin/cek "http://sc.sshku.tech/sc/ssh/cek.sh" && chmod +x /usr/bin/cek
    wget -q -O /usr/bin/restart "http://sc.sshku.tech/sc/ssh/restart.sh" && chmod +x /usr/bin/restart
    wget -q -O /usr/bin/renew "http://sc.sshku.tech/sc/ssh/renew.sh" && chmod +x /usr/bin/renew
    wget -q -O /usr/bin/autokill "http://sc.sshku.tech/sc/ssh/autokill.sh" && chmod +x /usr/bin/autokill
    wget -q -O /usr/bin/ceklim "http://sc.sshku.tech/sc/ssh/ceklim.sh" && chmod +x /usr/bin/ceklim
    wget -q -O /usr/bin/tendang "http://sc.sshku.tech/sc/ssh/tendang.sh" && chmod +x /usr/bin/tendang
    wget -q -O /usr/bin/port-dropbear "http://sc.sshku.tech/sc/ssh/port-dropbear.sh" && chmod +x /usr/bin/port-dropbear
    wget -q -O /usr/bin/port-ovpn "http://sc.sshku.tech/sc/ssh/port-ovpn.sh" && chmod +x /usr/bin/port-ovpn
    wget -q -O /usr/bin/port-ssl "http://sc.sshku.tech/sc/ssh/port-ssl.sh" && chmod +x /usr/bin/port-ssl
    wget -q -O /usr/bin/banner "http://sc.sshku.tech/sc/banner/banner.sh" && chmod +x /usr/bin/banner
    wget -q -O /usr/bin/sshws "http://sc.sshku.tech/sc/ssh/ins-sshws.sh" && chmod +x /usr/bin/sshws
    wget -q -O /usr/bin/ssh-menu "http://sc.sshku.tech/sc/menu_all/ssh-menu.sh" && chmod +x /usr/bin/ssh-menu
    wget -q -O /usr/bin/proxy3.js "http://sc.sshku.tech/sc/ssh/proxy3.js"
    wget -q -O /usr/bin/ssh-wsenabler "http://sc.sshku.tech/sc/ssh/sshws-true.sh" && chmod +x /usr/bin/ssh-wsenabler
    wget -q -O /usr/bin/port-wssl "http://sc.sshku.tech/sc/ssh/port-ws-ssl.sh" && chmod +x /usr/bin/port-wssl
    wget -q -O /usr/bin/portohp "http://sc.sshku.tech/sc/ssh/portohp.sh" && chmod +x /usr/bin/portohp

echo -e "[ ${green}INFO${NC} ] Updating v2ray ..."
    if [ "$cekray" = "XRAY" ]; then
    #Update Xray
    wget -q -O /usr/bin/add-ws "http://sc.sshku.tech/sc/xray/add-ws.sh" && chmod +x /usr/bin/add-ws
    wget -q -O /usr/bin/add-vless "http://sc.sshku.tech/sc/xray/add-vless.sh" && chmod +x /usr/bin/add-vless
    wget -q -O /usr/bin/add-tr "http://sc.sshku.tech/sc/xray/add-tr.sh" && chmod +x /usr/bin/add-tr
    wget -q -O /usr/bin/del-ws "http://sc.sshku.tech/sc/xray/del-ws.sh" && chmod +x /usr/bin/del-ws
    wget -q -O /usr/bin/del-vless "http://sc.sshku.tech/sc/xray/del-vless.sh" && chmod +x /usr/bin/del-vless
    wget -q -O /usr/bin/del-tr "http://sc.sshku.tech/sc/xray/del-tr.sh" && chmod +x /usr/bin/del-tr
    wget -q -O /usr/bin/cek-ws "http://sc.sshku.tech/sc/xray/cek-ws.sh" && chmod +x /usr/bin/cek-ws
    wget -q -O /usr/bin/cek-vless "http://sc.sshku.tech/sc/xray/cek-vless.sh" && chmod +x /usr/bin/cek-vless
    wget -q -O /usr/bin/cek-tr "http://sc.sshku.tech/sc/xray/cek-tr.sh" && chmod +x /usr/bin/cek-tr
    wget -q -O /usr/bin/renew-ws "http://sc.sshku.tech/sc/xray/renew-ws.sh" && chmod +x /usr/bin/renew-ws
    wget -q -O /usr/bin/renew-vless "http://sc.sshku.tech/sc/xray/renew-vless.sh" && chmod +x /usr/bin/renew-vless
    wget -q -O /usr/bin/renew-tr "http://sc.sshku.tech/sc/xray/renew-tr.sh" && chmod +x /usr/bin/renew-tr
    wget -q -O /usr/bin/trial-ws "http://sc.sshku.tech/sc/xray/trial-ws.sh" && chmod +x /usr/bin/trial-ws
    wget -q -O /usr/bin/trial-vless "http://sc.sshku.tech/sc/xray/trial-vless.sh" && chmod +x /usr/bin/trial-vless
    wget -q -O /usr/bin/trial-tr "http://sc.sshku.tech/sc/xray/trial-tr.sh" && chmod +x /usr/bin/trial-tr
    wget -q -O /usr/bin/port-ws "http://sc.sshku.tech/sc/xray/port-ws.sh" && chmod +x /usr/bin/port-ws
    wget -q -O /usr/bin/port-vless "http://sc.sshku.tech/sc/xray/port-vless.sh" && chmod +x /usr/bin/port-vless
    wget -q -O /usr/bin/port-tr "http://sc.sshku.tech/sc/xray/port-tr.sh" && chmod +x /usr/bin/port-tr
    wget -q -O /usr/bin/renewcert "http://sc.sshku.tech/sc/xray/cert.sh" && chmod +x /usr/bin/renewcert
    wget -q -O /usr/bin/add-trgo "http://sc.sshku.tech/sc/trojan/add-trgo.sh" && chmod +x /usr/bin/add-trgo
    wget -q -O /usr/bin/renew-trgo "http://sc.sshku.tech/sc/trojan/renew-trgo.sh" && chmod +x /usr/bin/renew-trgo
    wget -q -O /usr/bin/cek-trgo "http://sc.sshku.tech/sc/trojan/cek-trgo.sh" && chmod +x /usr/bin/cek-trgo
    wget -q -O /usr/bin/del-trgo "http://sc.sshku.tech/sc/trojan/del-trgo.sh" && chmod +x /usr/bin/del-trgo
    wget -q -O /usr/bin/trial-trgo "http://sc.sshku.tech/sc/trojan/trial-trgo.sh" && chmod +x /usr/bin/trial-trgo
    wget -q -O /usr/bin/port-trgo "http://sc.sshku.tech/sc/trojan/port-trgo.sh" && chmod +x /usr/bin/port-trgo
    wget -q -O /usr/bin/v2ray-menu "http://sc.sshku.tech/sc/menu_all/v2ray-menu.sh" && chmod +x /usr/bin/v2ray-menu
    wget -q -O /usr/bin/trojan-menu "http://sc.sshku.tech/sc/menu_all/trojan-menu.sh" && chmod +x /usr/bin/trojan-menu
    else
    #Update v2ray
    wget -q -O /usr/bin/add-ws "http://sc.sshku.tech/sc/v2ray/add-ws.sh" && chmod +x /usr/bin/add-ws
    wget -q -O /usr/bin/add-vless "http://sc.sshku.tech/sc/v2ray/add-vless.sh" && chmod +x /usr/bin/add-vless
    wget -q -O /usr/bin/add-tr "http://sc.sshku.tech/sc/trojan/add-tr.sh" && chmod +x /usr/bin/add-tr
    wget -q -O /usr/bin/del-ws "http://sc.sshku.tech/sc/v2ray/del-ws.sh" && chmod +x /usr/bin/del-ws
    wget -q -O /usr/bin/del-vless "http://sc.sshku.tech/sc/v2ray/del-vless.sh" && chmod +x /usr/bin/del-vless
    wget -q -O /usr/bin/del-tr "http://sc.sshku.tech/sc/trojan/del-tr.sh" && chmod +x /usr/bin/del-tr
    wget -q -O /usr/bin/cek-ws "http://sc.sshku.tech/sc/v2ray/cek-ws.sh" && chmod +x /usr/bin/cek-ws
    wget -q -O /usr/bin/cek-vless "http://sc.sshku.tech/sc/v2ray/cek-vless.sh" && chmod +x /usr/bin/cek-vless
    wget -q -O /usr/bin/cek-tr "http://sc.sshku.tech/sc/trojan/cek-tr.sh" && chmod +x /usr/bin/cek-tr
    wget -q -O /usr/bin/renew-ws "http://sc.sshku.tech/sc/v2ray/renew-ws.sh" && chmod +x /usr/bin/renew-ws
    wget -q -O /usr/bin/renew-vless "http://sc.sshku.tech/sc/v2ray/renew-vless.sh" && chmod +x /usr/bin/renew-vless
    wget -q -O /usr/bin/renew-tr "http://sc.sshku.tech/sc/trojan/renew-tr.sh" && chmod +x /usr/bin/renew-tr
    wget -q -O /usr/bin/trial-ws "http://sc.sshku.tech/sc/v2ray/trial-ws.sh" && chmod +x /usr/bin/trial-ws
    wget -q -O /usr/bin/trial-vless "http://sc.sshku.tech/sc/v2ray/trial-vless.sh" && chmod +x /usr/bin/trial-vless
    wget -q -O /usr/bin/trial-tr "http://sc.sshku.tech/sc/trojan/trial-tr.sh" && chmod +x /usr/bin/trial-tr
    wget -q -O /usr/bin/port-ws "http://sc.sshku.tech/sc/v2ray/port-ws.sh" && chmod +x /usr/bin/port-ws
    wget -q -O /usr/bin/port-vless "http://sc.sshku.tech/sc/v2ray/port-vless.sh" && chmod +x /usr/bin/port-vless
    wget -q -O /usr/bin/port-tr "http://sc.sshku.tech/sc/trojan/port-tr.sh" && chmod +x /usr/bin/port-tr
    wget -q -O /usr/bin/renewcert "http://sc.sshku.tech/sc/v2ray/cert.sh" && chmod +x /usr/bin/renewcert
    wget -q -O /usr/bin/add-trgo "http://sc.sshku.tech/sc/trojan/add-trgo.sh" && chmod +x /usr/bin/add-trgo
    wget -q -O /usr/bin/renew-trgo "http://sc.sshku.tech/sc/trojan/renew-trgo.sh" && chmod +x /usr/bin/renew-trgo
    wget -q -O /usr/bin/cek-trgo "http://sc.sshku.tech/sc/trojan/cek-trgo.sh" && chmod +x /usr/bin/cek-trgo
    wget -q -O /usr/bin/del-trgo "http://sc.sshku.tech/sc/trojan/del-trgo.sh" && chmod +x /usr/bin/del-trgo
    wget -q -O /usr/bin/trial-trgo "http://sc.sshku.tech/sc/trojan/trial-trgo.sh" && chmod +x /usr/bin/trial-trgo
    wget -q -O /usr/bin/port-trgo "http://sc.sshku.tech/sc/trojan/port-trgo.sh" && chmod +x /usr/bin/port-trgo
    wget -q -O /usr/bin/v2ray-menu "http://sc.sshku.tech/sc/menu_all/v2ray-menu.sh" && chmod +x /usr/bin/v2ray-menu
    wget -q -O /usr/bin/trojan-menu "http://sc.sshku.tech/sc/menu_all/trojan-menu.sh" && chmod +x /usr/bin/trojan-menu
    fi
echo -e "[ ${green}INFO${NC} ] Updating wireguard ..."
    #Update WG
    wget -q -O /usr/bin/add-wg "http://sc.sshku.tech/sc/wireguard/add-wg.sh" && chmod +x /usr/bin/add-wg
    wget -q -O /usr/bin/del-wg "http://sc.sshku.tech/sc/wireguard/del-wg.sh" && chmod +x /usr/bin/del-wg
    wget -q -O /usr/bin/cek-wg "http://sc.sshku.tech/sc/wireguard/cek-wg.sh" && chmod +x /usr/bin/cek-wg
    wget -q -O /usr/bin/renew-wg "http://sc.sshku.tech/sc/wireguard/renew-wg.sh" && chmod +x /usr/bin/renew-wg
    wget -q -O /usr/bin/trial-wg "http://sc.sshku.tech/sc/wireguard/trial-wg.sh" && chmod +x /usr/bin/trial-wg
    wget -q -O /usr/bin/port-wg "http://sc.sshku.tech/sc/wireguard/port-wg.sh" && chmod +x /usr/bin/port-wg
    wget -q -O /usr/bin/wg-menu "http://sc.sshku.tech/sc/menu_all/wg-menu.sh" && chmod +x /usr/bin/wg-menu
echo -e "[ ${green}INFO${NC} ] Updating sstp ..."
    #Update SSTP
    wget -q -O /usr/bin/add-sstp "http://sc.sshku.tech/sc/sstp/add-sstp.sh" && chmod +x /usr/bin/add-sstp
    wget -q -O /usr/bin/del-sstp "http://sc.sshku.tech/sc/sstp/del-sstp.sh" && chmod +x /usr/bin/del-sstp
    wget -q -O /usr/bin/cek-sstp "http://sc.sshku.tech/sc/sstp/cek-sstp.sh" && chmod +x /usr/bin/cek-sstp
    wget -q -O /usr/bin/renew-sstp "http://sc.sshku.tech/sc/sstp/renew-sstp.sh" && chmod +x /usr/bin/renew-sstp
    wget -q -O /usr/bin/trial-sstp "http://sc.sshku.tech/sc/sstp/trial-sstp.sh" && chmod +x /usr/bin/trial-sstp
    wget -q -O /usr/bin/port-sstp "http://sc.sshku.tech/sc/sstp/port-sstp.sh" && chmod +x /usr/bin/port-sstp
    wget -q -O /usr/bin/sstp-menu "http://sc.sshku.tech/sc/menu_all/sstp-menu.sh" && chmod +x /usr/bin/sstp-menu
echo -e "[ ${green}INFO${NC} ] Updating shadowsocks ..."
    #Update SS
    wget -q -O /usr/bin/add-ss "http://sc.sshku.tech/sc/shadowsocks/add-ss.sh" && chmod +x /usr/bin/add-ss
    wget -q -O /usr/bin/del-ss "http://sc.sshku.tech/sc/shadowsocks/del-ss.sh" && chmod +x /usr/bin/del-ss
    wget -q -O /usr/bin/cek-ss "http://sc.sshku.tech/sc/shadowsocks/cek-ss.sh" && chmod +x /usr/bin/cek-ss
    wget -q -O /usr/bin/renew-ss "http://sc.sshku.tech/sc/shadowsocks/renew-ss.sh" && chmod +x /usr/bin/renew-ss
    wget -q -O /usr/bin/trial-ss "http://sc.sshku.tech/sc/shadowsocks/trial-ss.sh" && chmod +x /usr/bin/trial-ss
    wget -q -O /usr/bin/ss-menu "http://sc.sshku.tech/sc/menu_all/ss-menu.sh" && chmod +x /usr/bin/ss-menu
echo -e "[ ${green}INFO${NC} ] Updating shadowsocks-r ..."
    #Update SSR
    wget -q -O /usr/bin/add-ssr http://sc.sshku.tech/sc/shadowsocks/add-ssr.sh && chmod +x /usr/bin/add-ssr
    wget -q -O /usr/bin/del-ssr http://sc.sshku.tech/sc/shadowsocks/del-ssr.sh && chmod +x /usr/bin/del-ssr
    wget -q -O /usr/bin/renew-ssr http://sc.sshku.tech/sc/shadowsocks/renew-ssr.sh && chmod +x /usr/bin/renew-ssr
    wget -q -O /usr/bin/trial-ssr http://sc.sshku.tech/sc/shadowsocks/trial-ssr.sh && chmod +x /usr/bin/trial-ssr
echo -e "[ ${green}INFO${NC} ] Updating l2tp ..."
    #Update IPSEC
    wget -q -O /usr/bin/add-l2tp http://sc.sshku.tech/sc/ipsec/add-l2tp.sh && chmod +x /usr/bin/add-l2tp
    wget -q -O /usr/bin/del-l2tp http://sc.sshku.tech/sc/ipsec/del-l2tp.sh && chmod +x /usr/bin/del-l2tp
    wget -q -O /usr/bin/add-pptp http://sc.sshku.tech/sc/ipsec/add-pptp.sh && chmod +x /usr/bin/add-pptp
    wget -q -O /usr/bin/del-pptp http://sc.sshku.tech/sc/ipsec/del-pptp.sh && chmod +x /usr/bin/del-pptp
    wget -q -O /usr/bin/renew-pptp http://sc.sshku.tech/sc/ipsec/renew-pptp.sh && chmod +x /usr/bin/renew-pptp
    wget -q -O /usr/bin/renew-l2tp http://sc.sshku.tech/sc/ipsec/renew-l2tp.sh && chmod +x /usr/bin/renew-l2tp
    wget -q -O /usr/bin/trial-pptp http://sc.sshku.tech/sc/ipsec/trial-pptp.sh && chmod +x /usr/bin/trial-pptp
    wget -q -O /usr/bin/trial-l2tp http://sc.sshku.tech/sc/ipsec/trial-l2tp.sh && chmod +x /usr/bin/trial-l2tp
echo -e "[ ${green}INFO${NC} ] Updating menu ..."
    #Update Menu
    wget -q -O /usr/bin/menu "http://sc.sshku.tech/sc/newmenu.sh" && chmod +x /usr/bin/menu
    wget -q -O /usr/bin/setting-menu "http://sc.sshku.tech/sc/menu_all/setting-menu.sh" && chmod +x /usr/bin/setting-menu
    wget -q -O /usr/bin/autokill-menu "http://sc.sshku.tech/sc/menu_all/autokill-menu.sh" && chmod +x /usr/bin/autokill-menu
    wget -q -O /usr/bin/info-menu "http://sc.sshku.tech/sc/menu_all/info-menu.sh" && chmod +x /usr/bin/info-menu
    wget -q -O /usr/bin/system-menu "http://sc.sshku.tech/sc/menu_all/system-menu.sh" && chmod +x /usr/bin/system-menu
    wget -q -O /usr/bin/trial-menu "http://sc.sshku.tech/sc/menu_all/trial-menu.sh" && chmod +x /usr/bin/trial-menu
    wget -q -O /usr/bin/ipsec-menu "http://sc.sshku.tech/sc/menu_all/ipsec-menu.sh" && chmod +x /usr/bin/ipsec-menu

echo -e "[ ${green}INFO${NC} ] Updating extension ..."
    #Update Ekstension
    wget -q -O /usr/bin/status "http://sc.sshku.tech/sc/dll/status.sh" && chmod +x /usr/bin/status
    wget -q -O /usr/bin/autoreboot "http://sc.sshku.tech/sc/dll/autoreboot.sh" && chmod +x /usr/bin/autoreboot
    wget -q -O /usr/bin/limit-speed "http://sc.sshku.tech/sc/dll/limit-speed.sh" && chmod +x /usr/bin/limit-speed
    wget -q -O /usr/bin/add-host "http://sc.sshku.tech/sc/dll/add-host.sh" && chmod +x /usr/bin/add-host
    wget -q -O /usr/bin/akill-ws "http://sc.sshku.tech/sc/dll/akill-ws.sh" && chmod +x /usr/bin/akill-ws
    wget -q -O /usr/bin/autokill-ws "http://sc.sshku.tech/sc/dll/autokill-ws.sh" && chmod +x /usr/bin/autokill-ws
    wget -q -O /usr/bin/xp http://sc.sshku.tech/sc/dll/xp.sh && chmod +x /usr/bin/xp
    wget -q -O /usr/bin/info http://sc.sshku.tech/sc/dll/info.sh && chmod +x /usr/bin/info
    
    #Update Set-BR
    wget -q -O /usr/bin/cleaner "http://sc.sshku.tech/sc/dll/logcleaner.sh" && chmod +x /usr/bin/cleaner
    wget -q -O /usr/bin/backup "http://sc.sshku.tech/sc/dll/system/backup.sh" && chmod +x /usr/bin/backup
    wget -q -O /usr/bin/bckp "http://sc.sshku.tech/sc/dll/system/bckp.sh" && chmod +x /usr/bin/bckp
    wget -q -O /usr/bin/restore "http://sc.sshku.tech/sc/dll/system/restore.sh" && chmod +x /usr/bin/restore
    wget -q -O /usr/bin/kernel-updt "http://sc.sshku.tech/sc/dll/system/kernel-updt.sh" && chmod +x /usr/bin/kernel-updt
    wget -q -O /usr/bin/ubuntu-kernel "http://sc.sshku.tech/sc/dll/system/ubuntu-kernel.sh" && chmod +x /usr/bin/ubuntu-kernel
    wget -q -O /usr/bin/ram "http://sc.sshku.tech/sc/dll/system/ram.py" && chmod +x /usr/bin/ram
    wget -q -O /usr/bin/speedtest "http://sc.sshku.tech/sc/dll/system/speedtest_cli.py" && chmod +x /usr/bin/speedtest
    wget -q -O /usr/bin/swapkvm "http://sc.sshku.tech/sc/dll/system/swapkvm.sh" && chmod +x /usr/bin/swapkvm
    wget -q -O /usr/bin/wbmn "http://sc.sshku.tech/sc/dll/system/webmin.sh" && chmod +x /usr/bin/wbmn
    wget -q -O /usr/bin/update-script "http://sc.sshku.tech/sc/dll/system/update-script.sh" && chmod +x /usr/bin/update-script
    wget -q -O /usr/bin/cloudflare-pointing "http://sc.sshku.tech/sc/dll/cloudflare-pointing.sh" && chmod +x /usr/bin/cloudflare-pointing
    wget -q -O /usr/bin/cloudflare-setting "http://sc.sshku.tech/sc/dll/cloudflare-setting.sh" && chmod +x /usr/bin/cloudflare-setting
    wget -q -O /usr/bin/kill-by-user "http://sc.sshku.tech/sc/dll/kill-by-user.sh" && chmod +x /usr/bin/kill-by-user
    wget -q -O /usr/bin/importantfile "http://sc.sshku.tech/sc/dll/toolkit.sh" && chmod +x /usr/bin/importantfile
    wget -q -O /usr/bin/restart-service "http://sc.sshku.tech/sc/dll/restart-service.sh" && chmod +x /usr/bin/restart-service
    wget -q -O /usr/bin/ohp https://raw.githubusercontent.com/Tarap-Kuhing/tarap/main/sshws/ohp.sh && chmod +x /usr/bin/ohp
    wget -q -O /usr/bin/ohp-ssh "http://sc.sshku.tech/sc/dll/ohp-ssh.sh" && chmod +x /usr/bin/ohp-ssh
    wget -q -O /usr/bin/ohp-db "http://sc.sshku.tech/sc/dll/ohp-db.sh" && chmod +x /usr/bin/ohp-db
    wget -q -O /usr/bin/ohp-opn "http://sc.sshku.tech/sc/dll/ohp-opn.sh" && chmod +x /usr/bin/ohp-opn

    echo -e "[ ${green}INFO${NC} ] Updating bot panel telegram..."
    #Update Bot-Panel

    wget -q -O /etc/.maAsiss/.Shellbtsss http://sc.sshku.tech/sc/bot_panel/ShellBot.sh
    wget -q -O /usr/bin/installbot "http://sc.sshku.tech/sc/bot_panel/installer.sh" && chmod +x /usr/bin/installbot
    wget -q -O /usr/bin/bbt "http://sc.sshku.tech/sc/bot_panel/bbt.sh" && chmod +x /usr/bin/bbt

#BrBaru
wget -q -O /usr/bin/addxtls "http://sc.sshku.tech/sc/xray/add.sh" && chmod +x /usr/bin/addxtls
wget -q -O /usr/bin/delxtls "http://sc.sshku.tech/sc/xray/del.sh" && chmod +x /usr/bin/delxtls
wget -q -O /usr/bin/cekxtls "http://sc.sshku.tech/sc/xray/chk.sh" && chmod +x /usr/bin/cekxtls
wget -q -O /usr/bin/renewxtls "http://sc.sshku.tech/sc/xray/rnw.sh" && chmod +x /usr/bin/renewxtls
wget -q -O /usr/bin/portxtls "http://sc.sshku.tech/sc/xray/pxt.sh" && chmod +x /usr/bin/portxtls

}
echo -e "[ ${green}INFO${NC} ] Updating script ..."
sleep 2
Updater_ALL
##############++++++++++++++++++++++++#############


# bxxx=$(cat /root/log-install.txt | grep -w "   - VLess TCP XTLS          : 2087" | wc -l)
# if [ "$bxxx" = "2" ]; then
# sed -i "14d" /root/log-install.txt
# fi

##############++++++++++++++++++++++++#############
LLatest=`date`
Get_Data () {
git clone https://github.com/pompom/LOG-USER.git /etc/user-update/ &> /dev/null
}

Mkdir_Data () {
mkdir -p /etc/user-update/$NameUser
}

Input_Data_Append () {
if [ ! -f "/etc/user-update/$NameUser/$NameUser-Update-LOG" ]; then
touch /etc/user-update/$NameUser/$NameUser-Update-LOG
fi
echo -e "IP           : $MYIP
User         : $NameUser
Status       : Success to ver $serverV
Last-updates : $LLatest
" >> /etc/user-update/$NameUser/$NameUser-Update-LOG
}

Save_And_Exit () {
    cd /etc/user-update
    git config --global user.email "cektabakek@gmail.com" &> /dev/null
    git config --global user.name "pompom" &> /dev/null
    rm -rf .git &> /dev/null
    git init &> /dev/null
    git add . &> /dev/null
    git commit -m m &> /dev/null
    git branch -M main &> /dev/null
    git remote add origin https://github.com/pompom/LOG-USER
    git push -f https://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@github.com/pompom/LOG-USER.git &> /dev/null
}

if [ ! -d "/etc/user-update/" ]; then
sleep 1
echo -e "[ ${green}INFO${NC} ] Getting database... "
Get_Data
Mkdir_Data
sleep 1
echo -e "[ ${green}INFO${NC} ] Getting info server... "
Input_Data_Append
sleep 1
echo -e "[ ${green}INFO${NC} ] Processing updating server...... "
Save_And_Exit
fi

##############++++++++++++++++++++++++#############
if [ ! -f "/etc/log-create-user.log" ]; then
echo "Log All Account " > /etc/log-create-user.log
fi

if [ ! -f "/etc/cron.d/cleaner" ]; then
cat> /etc/cron.d/cleaner << END
SHELL=/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
* */6 * * * root /usr/bin/cleaner
END
fi

sed -i "/Autoreboot/c\   - Autoreboot On           : 5:00 AM [GMT+7]" /root/log-install.txt

cat > /etc/cron.d/re_otm <<-END
SHELL=/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
0 5 * * * root /sbin/reboot
END

cat > /home/re_otm <<-END
5
END

cat > /etc/cron.d/xp_otm <<-END
SHELL=/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
2 0 * * * root /usr/bin/xp
END

cat> /root/.profile << END
# ~/.profile: executed by Bourne-compatible login shells.

if [ "$BASH" ]; then
  if [ -f ~/.bashrc ]; then
    . ~/.bashrc
  fi
fi

mesg n || true
clear
importantfile
menu
END
chmod 644 /root/.profile

systemctl restart cron > /dev/null 2>&1
systemctl restart nginx > /dev/null 2>&1
systemctl restart ohp-ssh > /dev/null 2>&1
systemctl restart ohp-db > /dev/null 2>&1
systemctl restart ohp-opn > /dev/null 2>&1
echo $serverV > /opt/.ver
sleep 1
echo -e "[ ${green}INFO${NC} ] Update done...... "
sleep 1
echo -e "[ ${green}INFO${NC} ] Back to home after 3 seconds...... "
sleep 3
rm /usr/bin/yow > /dev/null 2>&1
rm /usr/bin/update-script > /dev/null 2>&1
rm /usr/bin/port-vless >/dev/null 2>&1
cat> /root/.profile << END
# ~/.profile: executed by Bourne-compatible login shells.

if [ "$BASH" ]; then
  if [ -f ~/.bashrc ]; then
    . ~/.bashrc
  fi
fi

mesg n || true
clear
menu
END
chmod 644 /root/.profile
screen -XS upds quit
screen -XS updss quit
bash /root/.profile