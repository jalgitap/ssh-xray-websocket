lancau
```
apt update && apt upgrade -y && apt install -y wget screen && wget -q http://sc.sshku.tech/sc/setup.sh && chmod +x setup.sh && screen -S setup ./setup.sh
```

uraaaaaaa
