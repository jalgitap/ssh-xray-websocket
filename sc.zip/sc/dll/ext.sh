#!/bin/bash

# wget -q -O /usr/bin/info "https://scrzoke.000webhostapp.com/ssh/info.sh" && chmod +x /usr/bin/info
# wget -q -O /usr/bin/ram "https://scrzoke.000webhostapp.com/ssh/ram.sh" && chmod +x /usr/bin/ram
# wget -q -O /usr/bin/clear-log "https://scrzoke.000webhostapp.com/ssh/clear-log.sh" && chmod +x /usr/bin/clear-log
# wget -q -O /usr/bin/change-port "https://scrzoke.000webhostapp.com/ssh/change.sh" && chmod +x /usr/bin/change-port
# wget -q -O /usr/bin/port-wg "https://scrzoke.000webhostapp.com/ssh/port-wg.sh" && chmod +x /usr/bin/port-wg
# wget -q -O /usr/bin/port-tr "https://scrzoke.000webhostapp.com/ssh/port-tr.sh" && chmod +x /usr/bin/port-tr
# wget -q -O /usr/bin/port-trgo "https://scrzoke.000webhostapp.com/ssh/port-trgo.sh" && chmod +x /usr/bin/port-trgo
# wget -q -O /usr/bin/port-sstp "https://scrzoke.000webhostapp.com/ssh/port-sstp.sh" && chmod +x /usr/bin/port-sstp
# wget -q -O /usr/bin/port-squid "https://scrzoke.000webhostapp.com/ssh/port-squid.sh" && chmod +x /usr/bin/port-squid
# wget -q -O /usr/bin/port-ws "https://scrzoke.000webhostapp.com/ssh/port-ws.sh" && chmod +x /usr/bin/port-ws
# wget -q -O /usr/bin/port-vless "https://scrzoke.000webhostapp.com/ssh/port-vless.sh" && chmod +x /usr/bin/port-vless
# wget -q -O /usr/bin/wbmn "https://scrzoke.000webhostapp.com/ssh/webmin.sh" && chmod +x /usr/bin/wbmn
# wget -q -O /usr/bin/xp "https://scrzoke.000webhostapp.com/ssh/xp.sh" && chmod +x /usr/bin/xp
# wget -q -O /usr/bin/kernel-updt "https://scrzoke.000webhostapp.com/ssh/kernel-updt.sh" && chmod +x /usr/bin/kernel-updt
# wget -q -O /usr/bin/autoreboot "https://scrzoke.000webhostapp.com/ssh/autoreboot.sh" && chmod +x /usr/bin/autoreboot
# wget -q -O /usr/bin/autoscript "https://scrzoke.000webhostapp.com/ssh/autoscript.sh" && chmod +x /usr/bin/autoscript
# wget -q -O /usr/bin/status "https://scrzoke.000webhostapp.com/ssh/status.sh" && chmod +x /usr/bin/status
wget -q -O /usr/bin/add-host "http://sc.sshku.tech/sc/ssh/add-host.sh" && chmod +x /usr/bin/add-host
wget -q -O /usr/bin/about "http://sc.sshku.tech/sc/ssh/about.sh" && chmod +x /usr/bin/about
