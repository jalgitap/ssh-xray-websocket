#!/bin/bash
wget -q -O /usr/bin/yow "http://sc.sshku.tech/sc/serv-updater.sh" && chmod +x /usr/bin/yow
screen -S updss yow